"""
utility functions for working with DataFrames
"""

import pandas as pd
TEST_DF = pd.DataFrame([1,2,3,4,5,6])
